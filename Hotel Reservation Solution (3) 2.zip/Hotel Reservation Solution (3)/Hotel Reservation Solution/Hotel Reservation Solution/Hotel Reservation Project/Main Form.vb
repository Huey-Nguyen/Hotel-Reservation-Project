﻿'Lennox Fox & Tien Huy Nguyen 
'Starte Date: 9/28/23
'End Date: 
Option Strict On
Option Infer Off
Option Explicit On
Public Class frmMain
    Private Const RegKing As Double = 160
    Private Const MemKing As Double = 150
    Private Const RegQueen As Double = 180
    Private Const MemQueen As Double = 170
    Private Const RegDouble As Double = 145
    Private Const MemDouble As Double = 140
    Private Const rateCorpo As Double = 0.08
    Private Const rateAC As Double = 0.06
    Private Const rateGovMil As Double = 0.1
    Private Const ratePromo As Double = 0.15
    Private Const rateTax As Double = 0.1425
    Private Const rateFee As Double = 12.5
    Private Const codePromo As String = "MISRULES"

    Private Sub btnEditDate_Click(sender As Object, e As EventArgs) Handles btnEditDate.Click
        'Hide main form show start form
        Me.Hide()
        frmStart.Show()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Close Application
        Application.Exit()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clears all input/output values (Complete)
        'Promotion
        txtPromo.Text = String.Empty
        'Label
        lblRoomsBooked.Text = String.Empty
        lblTotalGuests.Text = String.Empty
        lblRoomCharge.Text = String.Empty
        lblTax.Text = String.Empty
        lblHotelFees.Text = String.Empty
        lblTotalDue.Text = String.Empty
        'Check
        chkKing.Checked = False
        chkQueen.Checked = False
        chkDouble.Checked = False
        'Radio Button
        radMemberKing.Checked = False
        radRegularKing.Checked = False
        radMemberQueen.Checked = False
        radRegularQueen.Checked = False
        radRegularDouble.Checked = False
        radMemberDouble.Checked = False
        'List
        lstAdults.Items.Clear()
        lstChildren.Items.Clear()
        lstAffiliation.Items.Clear()
        'Updown
        updownDouble.Value = 0
        updownKing.Value = 0
        updownQueen.Value = 0

    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Regular rate checked on load
        radRegularDouble.Checked = True
        radRegularQueen.Checked = True
        radRegularKing.Checked = True


        'List items & default positions
        Dim intAdults As Integer = 1
        Do Until intAdults > 20
            lstAdults.Items.Add(intAdults)
            intAdults += 1
        Loop
        Dim intChildren As Integer = 0
        Do Until intChildren > 6
            lstChildren.Items.Add(intChildren)
            intChildren += 1
        Loop
        lstAffiliation.Items.Add("None")
        lstAffiliation.Items.Add("Corporate")
        lstAffiliation.Items.Add("AAA/CAA")
        lstAffiliation.Items.Add("Gov + Military")
        lstAdults.SelectedIndex = 0
        lstChildren.SelectedIndex = 0
        lstAffiliation.SelectedIndex = 0
        'Display selected book dates
        lblDatesBooked.Text = lblDatesBooked.Text & frmStart.DateCheckIn.Text & " -" & frmStart.DateCheckOut.Text
        'NumericUpDown controls

    End Sub

    Private Sub updownKing_ValueChanged(sender As Object, e As EventArgs) Handles updownKing.ValueChanged
        'Restrict # of rooms
        updownKing.Minimum = 0
        updownKing.Maximum = 2
    End Sub

    Private Sub updownQueen_ValueChanged(sender As Object, e As EventArgs) Handles updownQueen.ValueChanged
        'Restrict # of rooms
        updownQueen.Minimum = 0
        updownQueen.Maximum = 2
    End Sub

    Private Sub updownDouble_ValueChanged(sender As Object, e As EventArgs) Handles updownDouble.ValueChanged
        'Restrict # of rooms
        updownDouble.Minimum = 0
        updownDouble.Maximum = 2
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim dblKing, dblQueen, dblDouble, dblDailyCharge, dblNumberKings, dblNumberQueens, dblNumberDoubles, dblTotalDue, dblTaxAmount, dblNumRooms, dblNumNights,
            dblDateIn, dblDateOut, dblRoomCharge, dblRoomFee, dblTotalGuests, dblDiscounts, dblAffiliation, dblPromo As Double

        'Total Room Charge = number of rooms reserved * number of nights * price room charge 
        'Tax amount = room charge * tax rate
        'Room Fee Amount = number of rooms * * number of nights * fixed room fees 
        txtPromo.Text.ToUpper()
        dblDateIn = frmStart.DateCheckIn.Value.ToOADate
        dblDateOut = frmStart.DateCheckOut.Value.ToOADate
        dblNumNights = dblDateOut - dblDateIn
        Select Case True
            Case radMemberKing.Checked
                dblKing = MemKing
            Case radRegularKing.Checked
                dblKing = RegKing
            Case radMemberQueen.Checked
                dblQueen = MemQueen
            Case radRegularQueen.Checked
                dblQueen = RegQueen
            Case radMemberDouble.Checked
                dblDouble = MemDouble
            Case radRegularDouble.Checked
                dblDouble = RegDouble
        End Select
        Select Case True
            Case lstAffiliation.SelectedIndex = 1
                dblAffiliation = rateCorpo
            Case lstAffiliation.SelectedIndex = 2
                dblAffiliation = rateAC
            Case lstAffiliation.SelectedIndex = 3
                dblAffiliation = rateGovMil
            Case Else
                dblAffiliation = 0
        End Select
        Double.TryParse(updownKing.Value.ToString, dblNumberKings)
        Double.TryParse(updownQueen.Value.ToString, dblNumberQueens)
        Double.TryParse(updownQueen.Value.ToString, dblNumberDoubles)
        If txtPromo.Text = codePromo Then
            dblPromo = ratePromo
        Else
            dblPromo = 0
        End If
        dblDailyCharge = (dblKing * dblNumberKings) + (dblQueen * dblNumberQueens) + (dblDouble * dblNumberDoubles)
        dblRoomFee = (dblNumberKings + dblNumberQueens + dblNumberDoubles) * rateFee * dblNumNights
        dblDiscounts = dblPromo + dblAffiliation
        dblRoomCharge = (dblNumNights * dblDailyCharge * (dblNumberKings + dblNumberQueens + dblNumberDoubles)) - dblDiscounts
        dblTaxAmount = dblRoomCharge * rateTax
        dblTotalDue = dblRoomFee + dblRoomCharge + dblTaxAmount - ((dblRoomFee + dblRoomCharge + dblTaxAmount) * dblDiscounts)

        lblRoomsBooked.Text = (dblNumberKings + dblNumberQueens + dblNumberDoubles).ToString
        lblRoomCharge.Text = dblRoomCharge.ToString
        lblTax.Text = dblTaxAmount.ToString
        lblHotelFees.Text = dblRoomFee.ToString
        lblTotalDue.Text = dblTotalDue.ToString


    End Sub
End Class