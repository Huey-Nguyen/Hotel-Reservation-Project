﻿'Lennox Fox & Tien Huy Nguyen 
'Starte Date: 9/28/23
'End Date: 
Option Strict On
Option Infer Off
Option Explicit On
'COMPLETED!
Public Class frmMain
    Private Const RegKing As Double = 160
    Private Const MemKing As Double = 150
    Private Const RegQueen As Double = 180
    Private Const MemQueen As Double = 170
    Private Const RegDouble As Double = 145
    Private Const MemDouble As Double = 140
    Private Const rateCorpo As Double = 0.08
    Private Const rateAC As Double = 0.06
    Private Const rateGovMil As Double = 0.1
    Private Const ratePromo As Double = 0.15
    Private Const rateTax As Double = 0.1425
    Private Const rateFee As Double = 12.5
    Private Const codePromo As String = "MISRULES"
    'COMPLETED!
    Private Sub btnEditDate_Click(sender As Object, e As EventArgs) Handles btnEditDate.Click
        'Hide main form show start form
        Me.Hide()
        frmStart.Show()
    End Sub
    'COMPLETED!
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Close Application
        Application.Exit()
    End Sub
    'COMPLETED!
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clears all input/output values (Complete)
        'Promotion
        txtPromo.Text = String.Empty
        'Label
        lblRoomsBooked.Text = String.Empty
        lblTotalGuests.Text = String.Empty
        lblRoomCharge.Text = String.Empty
        lblTax.Text = String.Empty
        lblHotelFees.Text = String.Empty
        lblTotalDue.Text = String.Empty
        'Check
        chkKing.Checked = False
        chkQueen.Checked = False
        chkDouble.Checked = False
        'Radio Button
        radMemberKing.Checked = False
        radRegularKing.Checked = True
        radMemberQueen.Checked = False
        radRegularQueen.Checked = True
        radRegularDouble.Checked = True
        radMemberDouble.Checked = False
        'List
        lstAdults.SelectedIndex = 0
        lstChildren.SelectedIndex = 0
        lstAffiliation.SelectedIndex = 0
        'Updown
        updownDouble.Value = 0
        updownKing.Value = 0
        updownQueen.Value = 0
    End Sub
    'COMPLETED!
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Regular rate checked on load
        radRegularDouble.Checked = True
        radRegularQueen.Checked = True
        radRegularKing.Checked = True
        'List items & default positions
        For intAdults As Integer = 1 To 20
            lstAdults.Items.Add(intAdults)
        Next
        For intChildren As Integer = 0 To 6
            lstChildren.Items.Add(intChildren)
        Next
        lstAffiliation.Items.Add("None")
        lstAffiliation.Items.Add("Corporate")
        lstAffiliation.Items.Add("AAA/CAA")
        lstAffiliation.Items.Add("Gov + Military")
        lstAdults.SelectedIndex = 0
        lstChildren.SelectedIndex = 0
        lstAffiliation.SelectedIndex = 0
        'Display selected book dates
        lblDatesBooked.Text = lblDatesBooked.Text & frmStart.DateCheckIn.Text & " -" & frmStart.DateCheckOut.Text
        'NumericUpDown controls
        updownKing.Enabled = False
        updownQueen.Enabled = False
        updownDouble.Enabled = False
        'RadioButton controls
        radRegularKing.Enabled = False
        radMemberKing.Enabled = False
        radRegularQueen.Enabled = False
        radMemberQueen.Enabled = False
        radRegularDouble.Enabled = False
        radMemberDouble.Enabled = False
    End Sub
    'COMPLETED!
    Private Sub chkKingRoom_CheckedChange(sender As Object, e As EventArgs) Handles chkKing.CheckedChanged
        'If King room is checked or not checked
        If chkKing.Checked = True Then
            updownKing.Enabled = True
            updownKing.Value = 1
            radRegularKing.Enabled = True
            radMemberKing.Enabled = True
        Else
            updownKing.Enabled = False
            updownKing.Value = 0
            radRegularKing.Enabled = False
            radMemberKing.Enabled = False
        End If
    End Sub
    Private Sub chkQueenRoom_CheckedChange(sender As Object, e As EventArgs) Handles chkQueen.CheckedChanged
        'If Queen room is checked or not checked
        If chkQueen.Checked = True Then
            updownQueen.Enabled = True
            updownQueen.Value = 1
            radRegularQueen.Enabled = True
            radMemberQueen.Enabled = True
        Else
            updownQueen.Enabled = False
            updownQueen.Value = 0
            radRegularQueen.Enabled = False
            radMemberQueen.Enabled = False
        End If
    End Sub
    Private Sub chkDoublesRoom_CheckedChange(sender As Object, e As EventArgs) Handles chkDouble.CheckedChanged
        'If Double room is checked or not checked
        If chkDouble.Checked = True Then
            updownDouble.Enabled = True
            updownDouble.Value = 1
            radRegularDouble.Enabled = True
            radMemberDouble.Enabled = True
        Else
            updownDouble.Enabled = False
            updownDouble.Value = 0
            radRegularDouble.Enabled = False
            radMemberDouble.Enabled = False
        End If
    End Sub
    'COMPLETED!
    Private Sub updownKing_ValueChanged(sender As Object, e As EventArgs) Handles updownKing.ValueChanged
        'Restrict # of rooms
        updownKing.Minimum = 0
        updownKing.Maximum = 2
    End Sub
    'COMPLETED!
    Private Sub updownQueen_ValueChanged(sender As Object, e As EventArgs) Handles updownQueen.ValueChanged
        'Restrict # of rooms
        updownQueen.Minimum = 0
        updownQueen.Maximum = 2
    End Sub
    'COMPLETED!
    Private Sub updownDouble_ValueChanged(sender As Object, e As EventArgs) Handles updownDouble.ValueChanged
        'Restrict # of rooms
        updownDouble.Minimum = 0
        updownDouble.Maximum = 2
    End Sub
    'COMPLETED!
    Private Sub txtPromo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPromo.KeyPress
        'Textbox promo code accepts uppercase text only
        If Not Char.IsLetter(e.KeyChar) AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        Else
            e.KeyChar = Char.ToUpper(e.KeyChar)
        End If
    End Sub
    'COMPLETED!
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Declare variables for calculations
        Dim dblKing, dblQueen, dblDouble, dblNumberKings, dblNumberQueens, dblNumberDoubles, dblTotalDue, dblTaxAmount, dblNumNights,
            dblDateIn, dblDateOut, dblRoomCharge, dblRoomFee, dblAdults, dblChildren, dblTotalGuests, dblTotalRooms, dblAffiliation, dblPromo,
        dblDailyChargeKing, dblDailyChargeQueen, dblDailyChargeDouble As Double
        'Determine nights booked
        dblDateIn = frmStart.DateCheckIn.Value.ToOADate
        dblDateOut = frmStart.DateCheckOut.Value.ToOADate
        dblNumNights = dblDateOut - dblDateIn
        'Select cases rooms
        'King rooms
        If chkKing.Checked = True Then
            Select Case True
                Case radMemberKing.Checked
                    dblKing = MemKing
                Case radRegularKing.Checked
                    dblKing = RegKing
            End Select
        Else
            dblKing = 0
        End If
        'Queen rooms
        If chkQueen.Checked = True Then
            Select Case True
                Case radMemberQueen.Checked
                    dblQueen = MemQueen
                Case radRegularQueen.Checked
                    dblQueen = RegQueen
            End Select
        Else
            dblQueen = 0
        End If
        'Doubles rooms
        If chkDouble.Checked = True Then
            Select Case True
                Case radMemberDouble.Checked
                    dblDouble = MemDouble
                Case radRegularDouble.Checked
                    dblDouble = RegDouble
            End Select
        Else
            dblDouble = 0
        End If
        'Determine discounts
        Select Case True
            Case lstAffiliation.SelectedIndex = 1
                dblAffiliation = rateCorpo
            Case lstAffiliation.SelectedIndex = 2
                dblAffiliation = rateAC
            Case lstAffiliation.SelectedIndex = 3
                dblAffiliation = rateGovMil
            Case Else
                dblAffiliation = 0
        End Select
        'Determine promo
        Dim PromoInput As String = txtPromo.Text.Trim()
        If PromoInput = codePromo Then
            dblPromo = ratePromo
        Else
            dblPromo = 0
        End If
        'Determine number of rooms  
        dblNumberKings = updownKing.Value
        dblNumberQueens = updownQueen.Value
        dblNumberDoubles = updownDouble.Value
        dblTotalRooms = dblNumberKings + dblNumberQueens + dblNumberDoubles
        'Determine number of guests
        Double.TryParse(lstAdults.SelectedItem.ToString, dblAdults)
        Double.TryParse(lstChildren.SelectedItem.ToString, dblChildren)
        dblTotalGuests = dblAdults + dblChildren
        'Total Calculation
        If chkKing.Checked = False And chkQueen.Checked = False And chkDouble.Checked = False Or dblTotalRooms = 0 Then
            'Stop if no rooms reserved
            MessageBox.Show("No Rooms Reserved", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        ElseIf dblTotalRooms * 5 < dblTotalGuests Then
            'Stop if guests exceed limit 
            MessageBox.Show("Guests Exceed Capacity of Room", "Exceed Capacity", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            'Continue if guests within limit
            'Calculate Fees
            dblRoomFee = dblTotalRooms * dblNumNights * rateFee
            'Calculate Daily Room Charge for each room type
            dblDailyChargeKing = dblKing * dblNumberKings
            dblDailyChargeQueen = dblQueen * dblNumberQueens
            dblDailyChargeDouble = dblDouble * dblNumberDoubles
            'Calculate Total Room Charge with discounts
            dblRoomCharge = dblNumNights * (dblDailyChargeKing + dblDailyChargeQueen + dblDailyChargeDouble)
            dblRoomCharge = dblRoomCharge * (1 - dblAffiliation) * (1 - dblPromo)
            'Calculate Tax
            dblTaxAmount = dblRoomCharge * rateTax
            'Calculate total 
            dblTotalDue = dblRoomCharge + dblTaxAmount + dblRoomFee
            'Display Results
            lblRoomsBooked.Text = dblTotalRooms.ToString
            lblRoomCharge.Text = dblRoomCharge.ToString("C2")
            lblTax.Text = dblTaxAmount.ToString("C2")
            lblHotelFees.Text = dblRoomFee.ToString("C2")
            lblTotalDue.Text = dblTotalDue.ToString("C2")
            lblTotalGuests.Text = dblTotalGuests.ToString
        End If
    End Sub
End Class