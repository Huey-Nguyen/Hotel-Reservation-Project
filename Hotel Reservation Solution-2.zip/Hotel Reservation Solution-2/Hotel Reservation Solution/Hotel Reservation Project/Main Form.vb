﻿'Lennox Fox & Tien Huy Nguyen 
'Starte Date: 9/28/23
'End Date: 
Option Strict On
Option Infer Off
Option Explicit On
Public Class frmMain
    Private Const RegKing As Double = 160
    Private Const MemKing As Double = 150
    Private Const RegQueen As Double = 180
    Private Const MemQueen As Double = 170
    Private Const RegDouble As Double = 145
    Private Const MemDouble As Double = 140
    Private Const rateCorpo As Decimal = 0.08D
    Private Const rateAC As Decimal = 0.06D
    Private Const rateGovMil As Decimal = 0.1D
    Private Const ratePromo As Decimal = 0.15D
    Private Const rateTax As Decimal = 0.1425D
    Private Const rateFee As Double = 12.5
    Private Const codePromo As String = "misrules"

    Private Sub btnEditDate_Click(sender As Object, e As EventArgs) Handles btnEditDate.Click
        'Hide main form show start form
        Me.Hide()
        frmStart.Show()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Close Application
        Application.Exit()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clears all input/output values (Complete)
        'Promotion
        txtPromo.Text = String.Empty
        'Label
        lblRoomsBooked.Text = String.Empty
        lblTotalGuests.Text = String.Empty
        lblRoomCharge.Text = String.Empty
        lblTax.Text = String.Empty
        lblHotelFees.Text = String.Empty
        lblTotalDue.Text = String.Empty
        'Check
        chkKing.Checked = False
        chkQueen.Checked = False
        chkDouble.Checked = False
        'Radio Button
        radMemberKing.Checked = False
        radRegularKing.Checked = False
        radMemberQueen.Checked = False
        radRegularQueen.Checked = False
        radRegularDouble.Checked = False
        radMemberDouble.Checked = False
        'List
        listAdults.Items.Clear()
        listChildren.Items.Clear()
        listAffiliation.Items.Clear()
        'Updown
        updownDouble.Value = 0
        updownKing.Value = 0
        updownQueen.Value = 0

    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Regular rate checked on load
        radRegularDouble.Checked = True
        radRegularQueen.Checked = True
        radRegularKing.Checked = True


        'List items & default positions
        Dim intAdults As Integer = 1
        Do Until intAdults > 20
            listAdults.Items.Add(intAdults)
            intAdults += 1
        Loop
        Dim intChildren As Integer = 0
        Do Until intChildren > 6
            listChildren.Items.Add(intChildren)
            intChildren += 1
        Loop
        listAffiliation.Items.Add("None")
        listAffiliation.Items.Add("Corporate")
        listAffiliation.Items.Add("AAA/CAA")
        listAffiliation.Items.Add("Gov + Military")
        listAdults.SelectedIndex = 0
        listChildren.SelectedIndex = 0
        listAffiliation.SelectedIndex = 0
        'Display selected book dates
        lblDatesBooked.Text = lblDatesBooked.Text & frmStart.DateCheckIn.Text & " -" & frmStart.DateCheckOut.Text
        'NumericUpDown controls

    End Sub

    Private Sub updownKing_ValueChanged(sender As Object, e As EventArgs) Handles updownKing.ValueChanged
        'Restrict # of rooms
        updownKing.Minimum = 0
        updownKing.Maximum = 2
    End Sub

    Private Sub updownQueen_ValueChanged(sender As Object, e As EventArgs) Handles updownQueen.ValueChanged
        'Restrict # of rooms
        updownQueen.Minimum = 0
        updownQueen.Maximum = 2
    End Sub

    Private Sub updownDouble_ValueChanged(sender As Object, e As EventArgs) Handles updownDouble.ValueChanged
        'Restrict # of rooms
        updownDouble.Minimum = 0
        updownDouble.Maximum = 2
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim dblTotalDueCharge, dblTaxAmount, dblNumRooms, dblNumNights, dblDateIn, dblDateOut, dblRoomCharge, dblRoomFee As Double
        Dim dblTotalGuests, dblTotalDue As Double
        'Total Room Charge = number of rooms reserved * number of nights * price room charge 
        'Tax amount = room charge * tax rate
        'Room Fee Amount = number of rooms * * number of nights * fixed room fees 

        dblDateIn = frmStart.DateCheckIn.Value.ToOADate
        dblDateOut = frmStart.DateCheckOut.Value.ToOADate
        dblNumNights = dblDateOut - dblDateIn
        'King rooms
        If chkKing.Checked Then
            Dim dblRegKingRooms, dblRegKingCharge, dblMem As Double
            Select Case True
                Case radMemberKing.Checked

            End Select
        End If
    End Sub
End Class