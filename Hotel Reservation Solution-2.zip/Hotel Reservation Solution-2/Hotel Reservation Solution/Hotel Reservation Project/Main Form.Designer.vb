﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpRoomType = New System.Windows.Forms.GroupBox()
        Me.updownDouble = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.chkDouble = New System.Windows.Forms.CheckBox()
        Me.grpRateDouble = New System.Windows.Forms.GroupBox()
        Me.radRegularDouble = New System.Windows.Forms.RadioButton()
        Me.radMemberDouble = New System.Windows.Forms.RadioButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.updownQueen = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.chkQueen = New System.Windows.Forms.CheckBox()
        Me.grpRateQueen = New System.Windows.Forms.GroupBox()
        Me.radRegularQueen = New System.Windows.Forms.RadioButton()
        Me.radMemberQueen = New System.Windows.Forms.RadioButton()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.updownKing = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.chkKing = New System.Windows.Forms.CheckBox()
        Me.grpRateKing = New System.Windows.Forms.GroupBox()
        Me.radRegularKing = New System.Windows.Forms.RadioButton()
        Me.radMemberKing = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.grpGuests = New System.Windows.Forms.GroupBox()
        Me.listChildren = New System.Windows.Forms.ListBox()
        Me.listAdults = New System.Windows.Forms.ListBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.grpCharges = New System.Windows.Forms.GroupBox()
        Me.lblTotalDue = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.lblHotelFees = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.lblRoomCharge = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.btnEditDate = New System.Windows.Forms.Button()
        Me.lblDatesBooked = New System.Windows.Forms.Label()
        Me.listAffiliation = New System.Windows.Forms.ListBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtPromo = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblRoomsBooked = New System.Windows.Forms.Label()
        Me.lblTotalGuests = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.grpRoomType.SuspendLayout()
        CType(Me.updownDouble, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpRateDouble.SuspendLayout()
        CType(Me.updownQueen, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpRateQueen.SuspendLayout()
        CType(Me.updownKing, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpRateKing.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpGuests.SuspendLayout()
        Me.grpCharges.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpRoomType
        '
        Me.grpRoomType.Controls.Add(Me.updownDouble)
        Me.grpRoomType.Controls.Add(Me.Label5)
        Me.grpRoomType.Controls.Add(Me.chkDouble)
        Me.grpRoomType.Controls.Add(Me.grpRateDouble)
        Me.grpRoomType.Controls.Add(Me.Label6)
        Me.grpRoomType.Controls.Add(Me.updownQueen)
        Me.grpRoomType.Controls.Add(Me.Label3)
        Me.grpRoomType.Controls.Add(Me.chkQueen)
        Me.grpRoomType.Controls.Add(Me.grpRateQueen)
        Me.grpRoomType.Controls.Add(Me.Label4)
        Me.grpRoomType.Controls.Add(Me.updownKing)
        Me.grpRoomType.Controls.Add(Me.Label2)
        Me.grpRoomType.Controls.Add(Me.chkKing)
        Me.grpRoomType.Controls.Add(Me.grpRateKing)
        Me.grpRoomType.Controls.Add(Me.Label1)
        Me.grpRoomType.Controls.Add(Me.PictureBox3)
        Me.grpRoomType.Controls.Add(Me.PictureBox2)
        Me.grpRoomType.Controls.Add(Me.PictureBox1)
        Me.grpRoomType.Location = New System.Drawing.Point(12, 35)
        Me.grpRoomType.Name = "grpRoomType"
        Me.grpRoomType.Size = New System.Drawing.Size(648, 627)
        Me.grpRoomType.TabIndex = 1
        Me.grpRoomType.TabStop = False
        Me.grpRoomType.Text = "Select your room"
        '
        'updownDouble
        '
        Me.updownDouble.Location = New System.Drawing.Point(299, 546)
        Me.updownDouble.Name = "updownDouble"
        Me.updownDouble.Size = New System.Drawing.Size(44, 23)
        Me.updownDouble.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(296, 528)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 15)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Rooms:"
        '
        'chkDouble
        '
        Me.chkDouble.AutoSize = True
        Me.chkDouble.Location = New System.Drawing.Point(299, 483)
        Me.chkDouble.Name = "chkDouble"
        Me.chkDouble.Size = New System.Drawing.Size(169, 19)
        Me.chkDouble.TabIndex = 4
        Me.chkDouble.Text = "Select Double Bed Room(s)"
        Me.chkDouble.UseVisualStyleBackColor = True
        '
        'grpRateDouble
        '
        Me.grpRateDouble.Controls.Add(Me.radRegularDouble)
        Me.grpRateDouble.Controls.Add(Me.radMemberDouble)
        Me.grpRateDouble.Location = New System.Drawing.Point(481, 483)
        Me.grpRateDouble.Name = "grpRateDouble"
        Me.grpRateDouble.Size = New System.Drawing.Size(149, 77)
        Me.grpRateDouble.TabIndex = 14
        Me.grpRateDouble.TabStop = False
        Me.grpRateDouble.Text = "Rate Type"
        '
        'radRegularDouble
        '
        Me.radRegularDouble.AutoSize = True
        Me.radRegularDouble.Location = New System.Drawing.Point(12, 47)
        Me.radRegularDouble.Name = "radRegularDouble"
        Me.radRegularDouble.Size = New System.Drawing.Size(88, 19)
        Me.radRegularDouble.TabIndex = 1
        Me.radRegularDouble.TabStop = True
        Me.radRegularDouble.Text = "Regular rate"
        Me.radRegularDouble.UseVisualStyleBackColor = True
        '
        'radMemberDouble
        '
        Me.radMemberDouble.AutoSize = True
        Me.radMemberDouble.Location = New System.Drawing.Point(12, 22)
        Me.radMemberDouble.Name = "radMemberDouble"
        Me.radMemberDouble.Size = New System.Drawing.Size(93, 19)
        Me.radMemberDouble.TabIndex = 0
        Me.radMemberDouble.TabStop = True
        Me.radMemberDouble.Text = "Member rate"
        Me.radMemberDouble.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(294, 438)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(147, 30)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "2 Double Beds"
        '
        'updownQueen
        '
        Me.updownQueen.Location = New System.Drawing.Point(299, 343)
        Me.updownQueen.Name = "updownQueen"
        Me.updownQueen.Size = New System.Drawing.Size(44, 23)
        Me.updownQueen.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(296, 325)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 15)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Rooms:"
        '
        'chkQueen
        '
        Me.chkQueen.AutoSize = True
        Me.chkQueen.Location = New System.Drawing.Point(299, 280)
        Me.chkQueen.Name = "chkQueen"
        Me.chkQueen.Size = New System.Drawing.Size(166, 19)
        Me.chkQueen.TabIndex = 2
        Me.chkQueen.Text = "Select Queen Bed Room(s)"
        Me.chkQueen.UseVisualStyleBackColor = True
        '
        'grpRateQueen
        '
        Me.grpRateQueen.Controls.Add(Me.radRegularQueen)
        Me.grpRateQueen.Controls.Add(Me.radMemberQueen)
        Me.grpRateQueen.Location = New System.Drawing.Point(481, 280)
        Me.grpRateQueen.Name = "grpRateQueen"
        Me.grpRateQueen.Size = New System.Drawing.Size(149, 77)
        Me.grpRateQueen.TabIndex = 11
        Me.grpRateQueen.TabStop = False
        Me.grpRateQueen.Text = "Rate Type"
        '
        'radRegularQueen
        '
        Me.radRegularQueen.AutoSize = True
        Me.radRegularQueen.Location = New System.Drawing.Point(12, 47)
        Me.radRegularQueen.Name = "radRegularQueen"
        Me.radRegularQueen.Size = New System.Drawing.Size(88, 19)
        Me.radRegularQueen.TabIndex = 1
        Me.radRegularQueen.TabStop = True
        Me.radRegularQueen.Text = "Regular rate"
        Me.radRegularQueen.UseVisualStyleBackColor = True
        '
        'radMemberQueen
        '
        Me.radMemberQueen.AutoSize = True
        Me.radMemberQueen.Location = New System.Drawing.Point(12, 22)
        Me.radMemberQueen.Name = "radMemberQueen"
        Me.radMemberQueen.Size = New System.Drawing.Size(93, 19)
        Me.radMemberQueen.TabIndex = 0
        Me.radMemberQueen.TabStop = True
        Me.radMemberQueen.Text = "Member rate"
        Me.radMemberQueen.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(294, 235)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(142, 30)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "2 Queen Beds"
        '
        'updownKing
        '
        Me.updownKing.Location = New System.Drawing.Point(299, 131)
        Me.updownKing.Name = "updownKing"
        Me.updownKing.Size = New System.Drawing.Size(44, 23)
        Me.updownKing.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(296, 113)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 15)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Rooms:"
        '
        'chkKing
        '
        Me.chkKing.AutoSize = True
        Me.chkKing.Location = New System.Drawing.Point(299, 68)
        Me.chkKing.Name = "chkKing"
        Me.chkKing.Size = New System.Drawing.Size(155, 19)
        Me.chkKing.TabIndex = 0
        Me.chkKing.Text = "Select King Bed Room(s)"
        Me.chkKing.UseVisualStyleBackColor = True
        '
        'grpRateKing
        '
        Me.grpRateKing.Controls.Add(Me.radRegularKing)
        Me.grpRateKing.Controls.Add(Me.radMemberKing)
        Me.grpRateKing.Location = New System.Drawing.Point(481, 68)
        Me.grpRateKing.Name = "grpRateKing"
        Me.grpRateKing.Size = New System.Drawing.Size(149, 77)
        Me.grpRateKing.TabIndex = 8
        Me.grpRateKing.TabStop = False
        Me.grpRateKing.Text = "Rate Type"
        '
        'radRegularKing
        '
        Me.radRegularKing.AutoSize = True
        Me.radRegularKing.Location = New System.Drawing.Point(12, 47)
        Me.radRegularKing.Name = "radRegularKing"
        Me.radRegularKing.Size = New System.Drawing.Size(88, 19)
        Me.radRegularKing.TabIndex = 1
        Me.radRegularKing.TabStop = True
        Me.radRegularKing.Text = "Regular rate"
        Me.radRegularKing.UseVisualStyleBackColor = True
        '
        'radMemberKing
        '
        Me.radMemberKing.AutoSize = True
        Me.radMemberKing.Location = New System.Drawing.Point(12, 22)
        Me.radMemberKing.Name = "radMemberKing"
        Me.radMemberKing.Size = New System.Drawing.Size(93, 19)
        Me.radMemberKing.TabIndex = 0
        Me.radMemberKing.TabStop = True
        Me.radMemberKing.Text = "Member rate"
        Me.radMemberKing.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(294, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 30)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "1 King Bed"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Hotel_Reservation_Project.My.Resources.Resources.Double_Bedroom
        Me.PictureBox3.Location = New System.Drawing.Point(19, 437)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(250, 175)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 2
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Hotel_Reservation_Project.My.Resources.Resources.Queen_Bedroom
        Me.PictureBox2.Location = New System.Drawing.Point(19, 230)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(250, 175)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Hotel_Reservation_Project.My.Resources.Resources.King_Bedroom
        Me.PictureBox1.Location = New System.Drawing.Point(19, 23)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(250, 175)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'grpGuests
        '
        Me.grpGuests.Controls.Add(Me.listChildren)
        Me.grpGuests.Controls.Add(Me.listAdults)
        Me.grpGuests.Controls.Add(Me.Label9)
        Me.grpGuests.Controls.Add(Me.Label8)
        Me.grpGuests.Location = New System.Drawing.Point(681, 5)
        Me.grpGuests.Name = "grpGuests"
        Me.grpGuests.Size = New System.Drawing.Size(188, 156)
        Me.grpGuests.TabIndex = 2
        Me.grpGuests.TabStop = False
        Me.grpGuests.Text = "Number of"
        '
        'listChildren
        '
        Me.listChildren.FormattingEnabled = True
        Me.listChildren.ItemHeight = 15
        Me.listChildren.Location = New System.Drawing.Point(106, 37)
        Me.listChildren.Name = "listChildren"
        Me.listChildren.Size = New System.Drawing.Size(52, 109)
        Me.listChildren.TabIndex = 3
        '
        'listAdults
        '
        Me.listAdults.FormattingEnabled = True
        Me.listAdults.ItemHeight = 15
        Me.listAdults.Location = New System.Drawing.Point(9, 37)
        Me.listAdults.Name = "listAdults"
        Me.listAdults.Size = New System.Drawing.Size(57, 109)
        Me.listAdults.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(103, 19)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 15)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Children:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 19)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(75, 15)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Adults (+18):"
        '
        'grpCharges
        '
        Me.grpCharges.Controls.Add(Me.lblTotalDue)
        Me.grpCharges.Controls.Add(Me.Label22)
        Me.grpCharges.Controls.Add(Me.lblHotelFees)
        Me.grpCharges.Controls.Add(Me.Label20)
        Me.grpCharges.Controls.Add(Me.lblTax)
        Me.grpCharges.Controls.Add(Me.Label18)
        Me.grpCharges.Controls.Add(Me.lblRoomCharge)
        Me.grpCharges.Controls.Add(Me.Label16)
        Me.grpCharges.Location = New System.Drawing.Point(681, 485)
        Me.grpCharges.Name = "grpCharges"
        Me.grpCharges.Size = New System.Drawing.Size(188, 177)
        Me.grpCharges.TabIndex = 14
        Me.grpCharges.TabStop = False
        Me.grpCharges.Text = "Charges"
        '
        'lblTotalDue
        '
        Me.lblTotalDue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalDue.Location = New System.Drawing.Point(81, 142)
        Me.lblTotalDue.Name = "lblTotalDue"
        Me.lblTotalDue.Size = New System.Drawing.Size(91, 26)
        Me.lblTotalDue.TabIndex = 3
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(8, 148)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(58, 15)
        Me.Label22.TabIndex = 7
        Me.Label22.Text = "Total due:"
        '
        'lblHotelFees
        '
        Me.lblHotelFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblHotelFees.Location = New System.Drawing.Point(81, 101)
        Me.lblHotelFees.Name = "lblHotelFees"
        Me.lblHotelFees.Size = New System.Drawing.Size(91, 26)
        Me.lblHotelFees.TabIndex = 2
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(8, 107)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(63, 15)
        Me.Label20.TabIndex = 6
        Me.Label20.Text = "Hotel fees:"
        '
        'lblTax
        '
        Me.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTax.Location = New System.Drawing.Point(81, 60)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(91, 26)
        Me.lblTax.TabIndex = 1
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(8, 66)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(27, 15)
        Me.Label18.TabIndex = 5
        Me.Label18.Text = "Tax:"
        '
        'lblRoomCharge
        '
        Me.lblRoomCharge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRoomCharge.Location = New System.Drawing.Point(81, 19)
        Me.lblRoomCharge.Name = "lblRoomCharge"
        Me.lblRoomCharge.Size = New System.Drawing.Size(91, 26)
        Me.lblRoomCharge.TabIndex = 0
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(8, 25)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(42, 15)
        Me.Label16.TabIndex = 4
        Me.Label16.Text = "Room:"
        '
        'btnEditDate
        '
        Me.btnEditDate.Location = New System.Drawing.Point(390, 11)
        Me.btnEditDate.Name = "btnEditDate"
        Me.btnEditDate.Size = New System.Drawing.Size(98, 23)
        Me.btnEditDate.TabIndex = 0
        Me.btnEditDate.Text = "&Edit Date"
        Me.btnEditDate.UseVisualStyleBackColor = True
        '
        'lblDatesBooked
        '
        Me.lblDatesBooked.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDatesBooked.Location = New System.Drawing.Point(12, 9)
        Me.lblDatesBooked.Name = "lblDatesBooked"
        Me.lblDatesBooked.Size = New System.Drawing.Size(343, 15)
        Me.lblDatesBooked.TabIndex = 11
        Me.lblDatesBooked.Text = "Booking for"
        '
        'listAffiliation
        '
        Me.listAffiliation.FormattingEnabled = True
        Me.listAffiliation.ItemHeight = 15
        Me.listAffiliation.Location = New System.Drawing.Point(690, 171)
        Me.listAffiliation.Name = "listAffiliation"
        Me.listAffiliation.Size = New System.Drawing.Size(163, 79)
        Me.listAffiliation.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(687, 263)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 15)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "Promo code:"
        '
        'txtPromo
        '
        Me.txtPromo.Location = New System.Drawing.Point(690, 281)
        Me.txtPromo.Name = "txtPromo"
        Me.txtPromo.Size = New System.Drawing.Size(163, 23)
        Me.txtPromo.TabIndex = 5
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(690, 313)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(163, 23)
        Me.btnCalculate.TabIndex = 6
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(690, 342)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(163, 23)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "C&lear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(690, 371)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(163, 23)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(687, 413)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(90, 15)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "Rooms booked:"
        '
        'lblRoomsBooked
        '
        Me.lblRoomsBooked.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRoomsBooked.Location = New System.Drawing.Point(783, 407)
        Me.lblRoomsBooked.Name = "lblRoomsBooked"
        Me.lblRoomsBooked.Size = New System.Drawing.Size(70, 26)
        Me.lblRoomsBooked.TabIndex = 9
        '
        'lblTotalGuests
        '
        Me.lblTotalGuests.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalGuests.Location = New System.Drawing.Point(783, 444)
        Me.lblTotalGuests.Name = "lblTotalGuests"
        Me.lblTotalGuests.Size = New System.Drawing.Size(70, 26)
        Me.lblTotalGuests.TabIndex = 10
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(687, 450)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 15)
        Me.Label14.TabIndex = 13
        Me.Label14.Text = "Total guests:"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(881, 671)
        Me.Controls.Add(Me.lblTotalGuests)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.lblRoomsBooked)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtPromo)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.listAffiliation)
        Me.Controls.Add(Me.lblDatesBooked)
        Me.Controls.Add(Me.btnEditDate)
        Me.Controls.Add(Me.grpCharges)
        Me.Controls.Add(Me.grpGuests)
        Me.Controls.Add(Me.grpRoomType)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Hotel Reservation"
        Me.grpRoomType.ResumeLayout(False)
        Me.grpRoomType.PerformLayout()
        CType(Me.updownDouble, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpRateDouble.ResumeLayout(False)
        Me.grpRateDouble.PerformLayout()
        CType(Me.updownQueen, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpRateQueen.ResumeLayout(False)
        Me.grpRateQueen.PerformLayout()
        CType(Me.updownKing, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpRateKing.ResumeLayout(False)
        Me.grpRateKing.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpGuests.ResumeLayout(False)
        Me.grpGuests.PerformLayout()
        Me.grpCharges.ResumeLayout(False)
        Me.grpCharges.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpRoomType As GroupBox
    Friend WithEvents updownDouble As NumericUpDown
    Friend WithEvents Label5 As Label
    Friend WithEvents chkDouble As CheckBox
    Friend WithEvents grpRateDouble As GroupBox
    Friend WithEvents radRegularDouble As RadioButton
    Friend WithEvents radMemberDouble As RadioButton
    Friend WithEvents Label6 As Label
    Friend WithEvents updownQueen As NumericUpDown
    Friend WithEvents Label3 As Label
    Friend WithEvents chkQueen As CheckBox
    Friend WithEvents grpRateQueen As GroupBox
    Friend WithEvents radRegularQueen As RadioButton
    Friend WithEvents radMemberQueen As RadioButton
    Friend WithEvents Label4 As Label
    Friend WithEvents updownKing As NumericUpDown
    Friend WithEvents Label2 As Label
    Friend WithEvents chkKing As CheckBox
    Friend WithEvents grpRateKing As GroupBox
    Friend WithEvents radRegularKing As RadioButton
    Friend WithEvents radMemberKing As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents grpGuests As GroupBox
    Friend WithEvents listChildren As ListBox
    Friend WithEvents listAdults As ListBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents grpCharges As GroupBox
    Friend WithEvents lblTotalDue As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents lblHotelFees As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents lblRoomCharge As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents btnEditDate As Button
    Friend WithEvents lblDatesBooked As Label
    Friend WithEvents listAffiliation As ListBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtPromo As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents lblRoomsBooked As Label
    Friend WithEvents lblTotalGuests As Label
    Friend WithEvents Label14 As Label
End Class
