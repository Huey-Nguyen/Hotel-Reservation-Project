﻿'Lennox Fox & Tien Huy Nguyen 
'Starte Date: 9/28/23
'End Date: 
Option Strict On
Option Infer Off
Option Explicit On
Public Class frmStart
    Public CheckIn As Date = DateTime.Today
    Public CheckOut As Date = DateTime.Today.AddDays(1)
    Private Sub btnBook_Click(sender As Object, e As EventArgs) Handles btnBook.Click
        'Message box alert (Completed, sort of)
        If DateCheckOut.Value <= CheckIn Then
            MessageBox.Show("Please enter valid dates.")
            Return
        ElseIf DateCheckIn.Value < CheckIn Then
            MessageBox.Show("You cannot book the date before today")
            Return
        Else
            'Hide start form show main form (Complete)
            Me.Hide()
            frmMain.Show()
        End If
    End Sub

    Private Sub frmStart_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Form load (complete)
        DateCheckIn.Value = CheckIn
        DateCheckOut.Value = CheckOut

    End Sub
End Class
