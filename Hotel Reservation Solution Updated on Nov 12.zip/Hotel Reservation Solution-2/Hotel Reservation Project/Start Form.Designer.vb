﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStart
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnBook = New System.Windows.Forms.Button()
        Me.DateCheckIn = New System.Windows.Forms.DateTimePicker()
        Me.DateCheckOut = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnBook
        '
        Me.btnBook.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnBook.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnBook.Location = New System.Drawing.Point(83, 119)
        Me.btnBook.Name = "btnBook"
        Me.btnBook.Size = New System.Drawing.Size(174, 47)
        Me.btnBook.TabIndex = 0
        Me.btnBook.Text = "BOOK NOW"
        Me.btnBook.UseVisualStyleBackColor = False
        '
        'DateCheckIn
        '
        Me.DateCheckIn.CustomFormat = " ddd, MMM dd"
        Me.DateCheckIn.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateCheckIn.Location = New System.Drawing.Point(43, 59)
        Me.DateCheckIn.Name = "DateCheckIn"
        Me.DateCheckIn.Size = New System.Drawing.Size(111, 23)
        Me.DateCheckIn.TabIndex = 2
        '
        'DateCheckOut
        '
        Me.DateCheckOut.CustomFormat = " ddd, MMM dd"
        Me.DateCheckOut.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateCheckOut.Location = New System.Drawing.Point(190, 59)
        Me.DateCheckOut.Name = "DateCheckOut"
        Me.DateCheckOut.Size = New System.Drawing.Size(111, 23)
        Me.DateCheckOut.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(40, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Check-in date:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(187, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 15)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Check-out date:"
        '
        'frmStart
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(340, 194)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DateCheckOut)
        Me.Controls.Add(Me.DateCheckIn)
        Me.Controls.Add(Me.btnBook)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.Name = "frmStart"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Hotel Reservation"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnBook As Button
    Friend WithEvents DateCheckIn As DateTimePicker
    Friend WithEvents DateCheckOut As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
