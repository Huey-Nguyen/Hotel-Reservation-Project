﻿'Lennox Fox & Tien Huy Nguyen 
'Starte Date: 9/28/23
'End Date: 
Option Strict On
Option Infer Off
Option Explicit On
Public Class frmMain
    Private Const RegKing As Double = 160
    Private Const MemKing As Double = 150
    Private Const RegQueen As Double = 180
    Private Const MemQueen As Double = 170
    Private Const RegDouble As Double = 145
    Private Const MemDouble As Double = 140
    Private Const rateCorpo As Double = 0.08
    Private Const rateAC As Double = 0.06
    Private Const rateGovMil As Double = 0.1
    Private Const ratePromo As Double = 0.15
    Private Const rateTax As Double = 0.1425
    Private Const rateFee As Double = 12.5
    Private Const codePromo As String = "MISRULES"

    Private Sub btnEditDate_Click(sender As Object, e As EventArgs) Handles btnEditDate.Click
        'Hide main form show start form
        Me.Hide()
        frmStart.Show()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Close Application
        Application.Exit()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clears all input/output values (Complete)
        'Promotion
        txtPromo.Text = String.Empty
        'Label
        lblRoomsBooked.Text = String.Empty
        lblTotalGuests.Text = String.Empty
        lblRoomCharge.Text = String.Empty
        lblTax.Text = String.Empty
        lblHotelFees.Text = String.Empty
        lblTotalDue.Text = String.Empty
        'Check
        chkKing.Checked = False
        chkQueen.Checked = False
        chkDouble.Checked = False
        'Radio Button
        radMemberKing.Checked = False
        radRegularKing.Checked = False
        radMemberQueen.Checked = False
        radRegularQueen.Checked = False
        radRegularDouble.Checked = False
        radMemberDouble.Checked = False
        'List
        lstAdults.SelectedIndex = 0
        lstChildren.SelectedIndex = 0
        lstAffiliation.SelectedIndex = 0
        'Updown
        updownDouble.Value = 0
        updownKing.Value = 0
        updownQueen.Value = 0

    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Regular rate checked on load
        radRegularDouble.Checked = True
        radRegularQueen.Checked = True
        radRegularKing.Checked = True


        'List items & default positions
        Dim intAdults As Integer = 1
        Do Until intAdults > 20
            lstAdults.Items.Add(intAdults)
            intAdults += 1
        Loop
        Dim intChildren As Integer = 0
        Do Until intChildren > 6
            lstChildren.Items.Add(intChildren)
            intChildren += 1
        Loop
        lstAffiliation.Items.Add("None")
        lstAffiliation.Items.Add("Corporate")
        lstAffiliation.Items.Add("AAA/CAA")
        lstAffiliation.Items.Add("Gov + Military")
        lstAdults.SelectedIndex = 0
        lstChildren.SelectedIndex = 0
        lstAffiliation.SelectedIndex = 0
        'Display selected book dates
        lblDatesBooked.Text = lblDatesBooked.Text & frmStart.DateCheckIn.Text & " -" & frmStart.DateCheckOut.Text
        'NumericUpDown controls
        updownKing.Enabled = False
        updownQueen.Enabled = False
        updownDouble.Enabled = False
        'RadioButton controls
        radRegularKing.Enabled = False
        radMemberKing.Enabled = False
        radRegularQueen.Enabled = False
        radMemberQueen.Enabled = False
        radRegularDouble.Enabled = False
        radMemberDouble.Enabled = False
    End Sub
    Private Sub chkRoom_CheckedChanged(sender As Object, e As EventArgs) Handles chkKing.CheckedChanged, chkQueen.CheckedChanged, chkDouble.CheckedChanged
        'If room is checked or not checked
        If chkKing.Checked = True Then
            updownKing.Enabled = True
            radRegularKing.Enabled = True
            radMemberKing.Enabled = True
        Else
            updownKing.Enabled = False
            radRegularKing.Enabled = False
            radMemberKing.Enabled = False
        End If

        If chkQueen.Checked = True Then
            updownQueen.Enabled = True
            radRegularQueen.Enabled = True
            radMemberQueen.Enabled = True
        Else
            updownQueen.Enabled = False
            radRegularQueen.Enabled = False
            radMemberQueen.Enabled = False
        End If

        If chkDouble.Checked = True Then
            updownDouble.Enabled = True
            radRegularDouble.Enabled = True
            radMemberDouble.Enabled = True
        Else
            updownDouble.Enabled = False
            radRegularDouble.Enabled = False
            radMemberDouble.Enabled = False
        End If
    End Sub
    Private Sub updownKing_ValueChanged(sender As Object, e As EventArgs) Handles updownKing.ValueChanged
        'Restrict # of rooms
        updownKing.Minimum = 0
        updownKing.Maximum = 2
    End Sub

    Private Sub updownQueen_ValueChanged(sender As Object, e As EventArgs) Handles updownQueen.ValueChanged
        'Restrict # of rooms
        updownQueen.Minimum = 0
        updownQueen.Maximum = 2
    End Sub

    Private Sub updownDouble_ValueChanged(sender As Object, e As EventArgs) Handles updownDouble.ValueChanged
        'Restrict # of rooms
        updownDouble.Minimum = 0
        updownDouble.Maximum = 2
    End Sub

    Private Sub txtPromo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPromo.KeyPress
        'Textbox promo code accepts uppercase text only
        If Not Char.IsLetter(e.KeyChar) AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        Else
            e.KeyChar = Char.ToUpper(e.KeyChar)
        End If

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Declare variables for calculations
        Dim dblKing, dblQueen, dblDouble, dblDailyCharge, dblNumberKings, dblNumberQueens, dblNumberDoubles, dblTotalDue, dblTaxAmount, dblNumNights,
            dblDateIn, dblDateOut, dblRoomCharge, dblRoomFee, dblAdults, dblChildren, dblTotalGuests, dblTotalRooms, dblAffiliation, dblPromo As Double

        'Determine nights booked
        dblDateIn = frmStart.DateCheckIn.Value.ToOADate
        dblDateOut = frmStart.DateCheckOut.Value.ToOADate
        dblNumNights = dblDateOut - dblDateIn
        'Determine rates for rooms
        Select Case True
            Case radMemberKing.Checked
                dblKing = MemKing
            Case radRegularKing.Checked
                dblKing = RegKing
            Case radMemberQueen.Checked
                dblQueen = MemQueen
            Case radRegularQueen.Checked
                dblQueen = RegQueen
            Case radMemberDouble.Checked
                dblDouble = MemDouble
            Case radRegularDouble.Checked
                dblDouble = RegDouble
        End Select
        'Determine discounts
        Select Case True
            Case lstAffiliation.SelectedIndex = 1
                dblAffiliation = rateCorpo
            Case lstAffiliation.SelectedIndex = 2
                dblAffiliation = rateAC
            Case lstAffiliation.SelectedIndex = 3
                dblAffiliation = rateGovMil
            Case Else
                dblAffiliation = 0
        End Select
        Dim PromoInput As String = txtPromo.Text.Trim()
        If PromoInput = codePromo Then
            dblPromo = ratePromo
        Else
            dblPromo = 0
        End If
        'Calculations
        'Values for how many rooms of each type
        Double.TryParse(updownKing.Value.ToString, dblNumberKings)
        Double.TryParse(updownQueen.Value.ToString, dblNumberQueens)
        Double.TryParse(updownQueen.Value.ToString, dblNumberDoubles)
        dblTotalRooms = dblNumberKings + dblNumberQueens + dblNumberDoubles
        'Determine number of guests
        Double.TryParse(lstAdults.SelectedItem.ToString, dblAdults)
        Double.TryParse(lstChildren.SelectedItem.ToString, dblChildren)
        dblTotalGuests = dblAdults + dblChildren
        If dblTotalRooms * 5 < dblTotalGuests Then
            'Stop if guests exceed limit 
            MessageBox.Show("Guests Exceed Capacity of Room", "Exceed Capacity", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            'Continue if guests within limit
            'Calculate Fees
            dblRoomFee = dblTotalRooms * dblNumNights * rateFee
            'Calculate Daily Room Charge
            dblDailyCharge = (dblKing * dblNumberKings) + (dblQueen * dblNumberQueens) + (dblDouble * dblNumberDoubles)
            'Calculate Room Charge
            dblRoomCharge = (dblTotalRooms * dblNumNights * dblDailyCharge)
            dblRoomCharge = dblRoomCharge * (1 - dblAffiliation)
            dblRoomCharge = dblRoomCharge * (1 - dblPromo)
            'Calculate Tax
            dblTaxAmount = dblRoomCharge * rateTax
            'Calculate total 
            dblTotalDue = dblRoomCharge + dblTaxAmount + dblRoomFee
            'Display Results
            lblRoomsBooked.Text = dblTotalRooms.ToString
            lblRoomCharge.Text = dblRoomCharge.ToString("C2")
            lblTax.Text = dblTaxAmount.ToString("C2")
            lblHotelFees.Text = dblRoomFee.ToString("C2")
            lblTotalDue.Text = dblTotalDue.ToString("C2")
            lblTotalGuests.Text = dblTotalGuests.ToString
        End If
    End Sub
End Class